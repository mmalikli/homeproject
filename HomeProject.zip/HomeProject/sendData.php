<?php

echo "<pre>";
print_r($_POST);//assatiative array it read it
print_r($_GET);
echo "</pre>";

?>